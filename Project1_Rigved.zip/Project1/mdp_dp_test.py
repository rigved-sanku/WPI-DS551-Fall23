#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Modified By Yanhua Li on 09/05/2022
# Modified By Yanhua Li on 09/09/2022 for gym==0.25.2
# Modified By Yanhua Li on 08/19/2023 for gymnasium==0.29.0
#
from mdp_dp import *
import gymnasium as gym
import sys
import numpy as np

"""
    This file includes unit test for mdp_dp.py
    You could test the correctness of your code by 
    typing 'nosetests -v mdp_dp_test.py' in the terminal
"""

# Evaluate non-deterministic
# env = gym.make('FrozenLake-v1',is_slippery=True,new_step_api=True)
env = gym.make('FrozenLake-v1', desc=None, map_name="4x4", is_slippery=True)
env = env.unwrapped
nS = env.observation_space.n
nA = env.action_space.n

# Evaluate deterministic
# env2 = gym.make('FrozenLake-v1',is_slippery=False,new_step_api=True)
env2 = gym.make('FrozenLake-v1', desc=None, map_name="4x4", is_slippery=False)
env2 = env2.unwrapped
nS2 = env2.observation_space.n
nA2 = env2.action_space.n

#---------------------------------------------------------------
def test_python_version():
    '''------Dynamic Programming for MDP (100 points in total)------'''
    assert sys.version_info[0] == 3 # require python 3

#---------------------------------------------------------------
def test_policy_evaluation():
    '''policy_evaluation (20 points)'''
    random_policy1 = np.ones([nS, nA]) / nA
    V1 = policy_evaluation(env.P, nS, nA, random_policy1,tol=1e-8)
    test_v1 = np.array([0.004, 0.004, 0.01 , 0.004, 0.007, 0. , 0.026, 0. , 0.019,
       0.058, 0.107, 0. , 0. , 0.13 , 0.391, 0. ])

    np.random.seed(595) # For students; When grading, another seed will be used 
    random_policy2 = np.random.rand(nS, nA)
    random_policy2 = random_policy2/random_policy2.sum(axis=1)[:,None]
    V2 = policy_evaluation(env.P, nS, nA, random_policy2,tol=1e-8)
    test_v2 = np.array([0.007, 0.007, 0.017, 0.007, 0.01 , 0. , 0.043, 0. , 0.029,
       0.093, 0.174, 0. , 0. , 0.215, 0.504, 0. ]) # in the example given to students
    # When grading with a different seed, the test_v2 will be a different one accordingly.

    assert np.allclose(test_v1,V1,atol=1e-3)
    assert np.allclose(test_v2,V2,atol=1e-3)
    

#---------------------------------------------------------------
def test_policy_improvement():
    '''policy_improvement (20 points)'''
    np.random.seed(595) # For students; When grading, another seed will be used
    V1 = np.random.rand(nS)
    new_policy1 = policy_improvement(env.P, nS, nA, V1)
    test_policy1 = np.array([[1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [0., 0., 0., 1.],
       [0., 0., 1., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [0., 0., 0., 1.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [0., 0., 1., 0.],
       [1., 0., 0., 0.]])
    # When grading with a different seed, the test_policy1 will be a different one accordingly.

    V2 = np.zeros(nS)
    new_policy2 = policy_improvement(env.P, nS, nA, V2)
    test_policy2 = np.array([[1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.]])
    
    assert np.allclose(test_policy1,new_policy1)
    assert np.allclose(test_policy2,new_policy2)

    
#---------------------------------------------------------------
def test_policy_iteration():
    '''policy_iteration (20 points)'''
    random_policy1 = np.ones([nS, nA]) / nA # Uniform distribution policy
    np.random.seed(595) # For students; When grading, another seed will be used 
    random_policy2 = np.random.rand(nS, nA)
    random_policy2 = random_policy2/random_policy2.sum(axis=1)[:,None] # Random policy

    policy_pi1, V_pi1 = policy_iteration(env.P, nS, nA, random_policy1,tol=1e-8)
    policy_pi2, V_pi2 = policy_iteration(env.P, nS, nA, random_policy2,tol=1e-8)

    optimal_policy = np.array([[1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.]])
    optimal_V = np.array([0.069, 0.061, 0.074, 0.056, 0.092, 0., 0.112, 0., 0.145,
       0.247, 0.3 , 0., 0., 0.38 , 0.639, 0.])


    policy_pi3, V_pi3 = policy_iteration(env2.P, nS2, nA2, random_policy1,tol=1e-8)
    optimal_policy2 = np.array([[0., 1., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 0., 1., 0.],
       [1., 0., 0., 0.]])
    optimal_V2 = np.array([0.59 , 0.656, 0.729, 0.656, 0.656, 0. , 0.81 , 0. , 0.729,
       0.81 , 0.9  , 0. , 0. , 0.9 , 1. , 0. ])


    assert np.allclose(policy_pi1,optimal_policy)
    assert np.allclose(V_pi1,optimal_V,atol=1e-3)
    assert np.allclose(policy_pi2,optimal_policy)
    assert np.allclose(V_pi2,optimal_V,atol=1e-3)
    assert np.allclose(policy_pi3,optimal_policy2)
    assert np.allclose(V_pi3,optimal_V2,atol=1e-3)


#---------------------------------------------------------------
def test_value_iteration():
    '''value_iteration (20 points)'''
    np.random.seed(595) # For students; When grading, another seed will be used 
    V1 = np.random.rand(nS)
    policy_vi1, V_vi1 = value_iteration(env.P, nS, nA, V1, tol= 1e-8)

    V2 = np.zeros(nS)
    policy_vi2, V_vi2 = value_iteration(env.P, nS, nA, V2, tol= 1e-8)

# Below are two optimal policies (including optimal_policy and optimal_policy_2nd) 
# both with the same optimal value function;
# So no matter which policy your VI converges to, it is fine.

    optimal_policy = np.array([[1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.]])

    optimal_policy_2nd = np.array([[1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [1., 0., 0., 0.],
       [0., 0., 0., 1.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.]])

    optimal_V = np.array([0.069, 0.061, 0.074, 0.056, 0.092, 0. , 0.112, 0. , 0.145,
        0.247, 0.3  , 0. , 0. , 0.38 , 0.639, 0. ])

    policy_vi3, V_vi3 = value_iteration(env2.P, nS2, nA2, V2)

    optimal_policy2 = np.array([[0., 1., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 1., 0., 0.],
       [0., 1., 0., 0.],
       [1., 0., 0., 0.],
       [1., 0., 0., 0.],
       [0., 0., 1., 0.],
       [0., 0., 1., 0.],
       [1., 0., 0., 0.]])
    optimal_V2 = np.array([0.59 , 0.656, 0.729, 0.656, 0.656, 0. , 0.81 , 0. , 0.729,
       0.81 , 0.9  , 0. , 0. , 0.9 , 1. , 0. ])

    
    assert np.allclose(policy_vi1,optimal_policy) or np.allclose(policy_vi1, optimal_policy_2nd)
    assert np.allclose(V_vi1,optimal_V,atol=1e-3) 
    assert np.allclose(policy_vi2,optimal_policy) or np.allclose(policy_vi2, optimal_policy_2nd)
    assert np.allclose(V_vi2,optimal_V,atol=1e-3)
    assert np.allclose(policy_vi3,optimal_policy2)
    assert np.allclose(V_vi3,optimal_V2,atol=1e-3)

#---------------------------------------------------------------            
def test_render_single():
    '''render_single (20 points)'''                 
   #  print("\n" + "-"*25 + "\nBeginning Policy Iteration\n" + "-"*25)
    random_policy = np.ones([nS, nA]) / nA
    p_pi, V_pi = policy_iteration(env.P, nS, nA, random_policy,tol=1e-8)
    r_pi = render_single(env, p_pi, False, 50)
   #  print("total rewards of PI: ",r_pi)
    
   #  print("\n" + "-"*25 + "\nBeginning Value Iteration\n" + "-"*25)
    V = np.zeros(nS)
    p_vi, V_vi = value_iteration(env.P, nS, nA, V,tol=1e-8)
    r_vi = render_single(env, p_vi, False, 50)
   #  print("total rewards of VI: ",r_vi)
    
    
    assert r_pi > 30
    assert r_vi > 30
